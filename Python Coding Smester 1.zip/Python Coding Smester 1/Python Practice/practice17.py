
i=1
row=int(input('Enter Rows'))
while i <=row:
    j=1
    while j<i:
        print(' ',end='')
        j+=1
    print(i)
    i+=1



i=1
row=int(input('Enter Rows'))
while i <=row:
    j=i
    while j<row:
        print(' ',end='')
        j+=1
    print(i)
    i+=1



i=1
row=int(input('Enter Rows'))
col=int(input('Enter Columns'))
while i <=row:
    j=1
    while j<=col:
        print(i,end='')
        j+=1
    print()
    i+=1



i=1
row=int(input('Enter Rows'))
col=int(input('Enter Columns'))
while i <=row:
    j=1
    while j<=col:
        print(f'{i}',end='')
        j+=1
    print()
    k=1
    while k<=col:
        print(chr(i+96),end='')
        k+=1
    print()
    i+=1


i=1
row=int(input('Enter Rows'))
col=int(input('Enter Columns'))
while i <=row:
    j=i
    while j<=col+i-1:
        print(f'{j}',end='')
        j+=1
    print()
    k=i
    while k<=col+i-1:
        print(chr(k+96),end='')
        k+=1
    print()
    i+=1
