from random import *

# list = [23, 45, 18, 23, 17, 45, 36, 23, 45, 18, 36, 45, 18, 17, 36, 23, 17]
# sen=-1
# for i in range(len(list)):
#     for j in range(i+1,len(list)):
#         if list[i]==list[j]:
#             list[j]=sen        
#     if sen!=list[i]:
#         print(list[i],end=' ')


# list = [23, 45, 18, 23, 17, 45, 36, 23, 45, 18, 36, 45, 18, 17, 36, 23, 17]
# print(f'X:{list}')
# list1=[]
# sen=-1
# for i in range(len(list)):
#     for j in range(i+1,len(list)):
#         if list[i]==list[j]:
#             list[j]=sen        
#     if sen!=list[i]:
#         list1.append(list[i])
# print(f'Y:{list1}')

# Shor cut method for these two prblems
# list = [23, 45, 18, 23, 17, 45, 36, 23, 45, 18, 36, 45, 18, 17, 36, 23, 17]
# list1=[]
# for i in list:
#     if i not in list1:
#         list1.append(i)
# print(list1)


# list = [23, 45, 18, 23, 17, 45, 36, 23, 45, 18, 36, 45, 18, 17, 36, 23, 17]
# list1=list2=[]
# sen=-1
# for i in range(len(list)):
#     count=1
#     for j in range(i+1,len(list)):
#         if list[i]==list[j]:
#             list[j]=sen
#             count+=1
            
#     if sen!=list[i]:
#         list1.append(list[i])
#         print(f'{list[i]} has count {count}')


# column=4
# row=3
# x=[[randint(30,70) for j in range(column)]for i in range(row)]
# print(x)
# for i in range(row):
#     for j in range(column):
#         print(x[i][j],end=' ')
# print()
# for i in range(row):
#     for j in range(column):
#         print(x[i][j],end=' ')
#     print()
# 
    
# column=4
# row=4
# x=[[randint(30,70) for j in range(column)]for i in range(row)]
# for i in range(row):
#     for j in range(column):
#         print(x[i][j],end=' ')
#     print()
# print(f'printcipal diagonal:',end=' ')
# for i in range(row):
#     print(f'{x[i][i]}',end=' ')
# print()
# print(f'secondary diagonal:',end= ' ')
# for i in range(row):
#     print(x[i][row-1-i],end=' ') 
# 

# column=3
# row=4
# x=[[randint(30,70) for j in range(column)]for i in range(row)]
# for i in range(row):
#     sum=0
#     for j in range(column):
#         print(x[i][j],end=' ')
#         sum+=x[i][j]
#     print(f'= {sum}')

#    