
from random import *    
# a = int(input('enterr a'))
# b = int(input('enterr b'))
# c = int(input('enterr c'))
# Disc = b*b -4*a*c
# if a==0:
#     print('EQUATION IS LINEAR AND HAS ONLY ONE ROOT')
# elif Disc<0 :
#     print('Roots are Imaginary')
# else :
#     Denom =int(2*a)
#     root1= int((-b+Disc)/Denom)
#     root2= int((-b-Disc)/Denom)
#     print(root1 , root2)


# a = randint(1,10)
# x = int(input('First Chance enter Number'))
# if x == a :
#     print('Winner')
# else :
#      x =  int(input('Enter Number Second Chance'))
#      if x == a :
#             print('Winner')
#      else:
#         x = int(input('Enter Number Third Chance'))
#         if x == a: 
#             print('Winner')
#         else:
#             print(f'Loser and Number is this {a}')



# x = randint(1,10)
# y = randint(1,10)
# z = randint(1,10)
# print(x,y,z)
# if x+2 == y and y+2 == z:
#     print('Ok')
# elif z-2 == y and y-2 == z:
#     print('Ok')
# else :
#     print('Sorry')


x1=randint(1,10000)
x2=randint(1,10000)
x3=randint(1,10000)
print(x1,x2,x3)
if x1<x2:
    x1,x2=x2,x1
if x2<x3:
    x2,x3=x3,x2
if x1<x2:
    x1,x2=x2,x1
print(x1,x2,x3)