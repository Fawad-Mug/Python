# x = int(input('Enter First Number'))
# y = int(input('Enter Second Number'))
# z = int(input('Enter Third Number'))
# t = (x+y+z)/3
# print (int(t))

# a = int(input('Enter First Number'))
# b = int(input('Enter Second Number'))
# print(a+b)
# print(a-b)
# print(a*b)

# d = int(input('Enter hours'))
# e = d*60
# print(e)

# f = int(input('Enter Seconds'))
# g = int(f//3600)
# h = int(f//60)
# i = int(f%60 )
# print(f)
# print(g)
# print(h)
# print(i)

# j = (input('Enter any string'))
# k = (input('Enter another string'))
# print(len(j))
# print(len(k))
# print(len(j)+len(k))