'''
n=0
def even_number(n):
    n=int(input('Enter Numbers'))
    for i in range(0,n,2):
        print(i)
even_number(n)



c=0
n=0
def print_char(c,n):
    c=int(input('Enter C'))
    n=int(input('Enter n'))
    for i in range(n):
        print('*',end=' ')
print_char(c,n)

def print_char(c,n):
    for i in range(n):
        print(c,end=' ')
print_char('&',10)




def print_counting(n,d):
    k=1
    for i in range(n):
        print(k,end=' ')
        k+= d
print_counting(20,2)



def sum_integers(n):
    add=0
    for i in range(1,n+1):
        add = add + i
    return add
print(sum_integers(6))



def next_vowel(c):
    if ord(c)< ord('E'):
        return 'E'
    elif ord(c)< ord('I'):
        return 'I'
    if ord(c)< ord('O'):
        return 'O'
    elif ord(c)< ord('U'):
        return 'U'
    else:
        return 'A'
print(next_vowel('L'))
'''
