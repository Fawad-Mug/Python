from random import *

# x=randint(1,10)
# y=randint(1,10)
# while x==y:
#     y=randint(1,10)
# z=randint(1,10)
# while z==x or z==y:
#     z=randint(1,10)
# print(x,y,z)

# x = randint(1, 10)
# y = randint(1, 10)*x
# print(x, y)


# count=0
# sum=0
# for i in range(1,100):
#     x=randint(1,10)
#     y=randint(1,10)
#     count+=1
#     z=x+y
#     sum=sum+z
#     print(sum)
#     if sum ==50 or sum > 50:
#         break
# print(f'{count}loop')


# for i in range(5):
#     x=randint(65,90)
#     while x==65 or x==69 or x==73 or x==79 or x==85:
#         x=randint(65,69)
#     print(chr(x ),end=' ')

    
# a=randint(1,10)
# for i in range(10):
#     add=randint(2,3)
#     a+=add
#     print(a)



# sum=0
# while sum!=50:
#     x=randint(1,10)
#     sum+=x
#     if sum > 50:
#         sum=0
# print(sum)



# r=int(input())
# for i in range (r):
#     for j in range(i):
#         print(' ',end='')
#     print('\\',end='')
#     print()
# for m in range (r):
#     print(' ',end='')
# for n in range (r):
#     print('-',end='')       
# print()
# for k in range (1,r+1):
#     for l in range(k,r):
#         print(' ',end='')
#     print('/',end='')
#     print()


# r=int(input())
# c=int(input())
# for i in range(c):
#     print('o',end='')
# print()
# for j in range(r):
#     for k in range(c):
#         print(end=' ')
#     print()
# for  k in range(c-2):
#     print(end='')
#     for l in range(c-2):
#         print('w')
# for i in range(c):
#     print('o',end='')