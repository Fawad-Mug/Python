# firstNumber = int(input('Enter First Number'))
# SecondNumber = int(input('Enter Second Number'))
# if firstNumber-SecondNumber <= 1:
#    print('Print is almost Equal')
# else:
#   print('print is not Equal')                                 

# firstNumber = int(input('Enter First Number'))
# SecondNumber = int(input('Enter Second Number'))
# if firstNumber-SecondNumber== 1:
#    print('Print is almost Equal')
# elif firstNumber == SecondNumber:
#   print('print are exactly same')                                 
# else:
#   print('Print is not equal')

#a = int(input('Enter Marks'))
#if a>= 85:
#    print(f'Marks:\t\t{a}\nGrade:\t\tA')
#elif a>= 80:
#    print(f'Marks:\t\t{a}\nGrade:\t\tA-')
#elif a>= 75:
#    print(f'Marks:\t\t{a}\nGrade:\t\tB+')
#elif a>= 70:
#    print(f'Marks:\t\t{a}\nGrade:\t\tB')
#elif a>= 65:
#    print(f'Marks:\t\t{a}\nGrade:\t\tB-')
#elif a>= 61:
#    print(f'Marks:\t\t{a}\nGrade:\t\tC+')
#elif a>= 58:
#    print(f'Marks:\t\t{a}\nGrade:\t\tC')
#elif a>= 55:
#    print(f'Marks:\t\t{a}\nGrade:\t\tC-')
#elif a>= 50:
#    print(f'Marks:\t\t{a}\nGrade:\t\tD')
#elif a<= 50:
#    print(f'Marks:\t\t{a}\nGrade:\t\tF') 

#a = int(input('Enter Marks'))
#if a>= 85:
#    print(f'Marks:\t\t{a}\nGrade:\t\tA')
#elif a>= 80:
#    print(f'Marks:\t\t{a}\nGrade:\t\tA-')
#elif a>= 75: 
#    print(f'Marks:\t\t{a}\nGrade:\t\tB+')
#elif a>= 70:
#    print(f'Marks:\t\t{a}\nGrade:\t\tB')
#elif a>= 65:
#    print(f'Marks:\t\t{a}\nGrade:\t\tB-')
#elif a>= 61:
#        print(f'Marks:\t\t{a}\nGrade:\t\tC+')
#elif a>= 58:
#    print(f'Marks:\t\t{a}\nGrade:\t\tC')
#elif a>= 55:
#    print(f'Marks:\t\t{a}\nGrade:\t\tC-')
#elif a>= 50:
#    print(f'Marks:\t\t{a}\nGrade:\t\tD')
#elif a<= 50:
#    print(f'Marks:\t\t{a}\nGrade:\t\tF') 

#from random import *
#V1 = randint(1,5)
#v2 = randint(1,5)
#diff= V1-v2
#if diff<=1:
#    print('Numbers are almost equal')
#else:
#    print('Numbers are not equal')


#eggs = int(input('Enter Nummber of Eggs'))
#x = eggs/6
#y = eggs//6
#if x>y : 
#    print (y+1)
#else :
#    print(x)


# first_length =int(input('Enter First Rectangle Length'))
# first_width =int(input('Enter First Rectangle Width'))
# second_length =int(input('Enter Second Rectangle Length'))
# second_width =int(input('Enter Second Rectangle Width'))
# first_rectangle = first_length * first_width
# second_rectangle = second_length * second_width
# if first_rectangle > second_rectangle:
#     small = 'second'
# else:
#     small = 'first'
# print(f'Result: {small} rectangle is smaller')
x=int(input())
if x>=85:
    grade='A'
elif x>=80:
    grade ='B-'
elif x>=50:
    grade='F'
print(grade)