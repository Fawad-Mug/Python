def square(r,c):
    for i in range(c):
        print('*',end=' ')
    print()
    for j in range(r-2):
        print('*',end='')
        for k in range((c*2)-3):
            print(' ',end='')
        print('*')
        print()
    for l in range(c):
        print('*',end=' ')
    print()
square(5,10)




def table (n,k):
    l=1
    for i in range(k):
        print(n*l,end=' ')
        l+=1
table(7,4)





from random import*
def rand(n,a,b):
    for i in range(n):
        x= randint(a,b)
        print(x,end=' ')
rand(5,5,11)




  

def root(a,b,c):
    disc = ((b*b)-(4*a*c))**(0.5)
    r1=(-b+disc)/(2*a)
    r2=(b+disc)/(2*a)
    print(r1,r2)
root(3,5,2)





mid=0
def middle_Value(a,b,c):
    if a<b and b<c:
        mid = b
    elif a>b and b>c:
        mid = b
    elif c<b and c<a:
        mid = b
    elif c>b and c>a:
        mid = b
    else:
        mid=a
    return mid
print(middle_Value(9,8,5))





def avg(a,b,c):
    ang=(a+b+c)/3
    return ang
print(avg(9,8,7))





def squares(a,b):
    x=a**b
    return x
print(squares(2,5))



def vowel(a):
    if ord (a)<ord('e'):
        return 'e'
    elif ord(a)<ord('i'):
        return 'i'
    elif ord (a)<ord('o'):
        return 'o'
    elif ord(a)<ord('u'):
        return 'u'
    else:
        return 'a'
print(vowel('c'))
