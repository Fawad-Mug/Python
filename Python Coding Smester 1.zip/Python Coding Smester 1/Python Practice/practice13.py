# f=open('nums.txt','r')
# i=0
# count=0
# while i <10000:
#     n = int(f.readline())
#     count += n
#     i += 1
# f.close()
# avg=count/10000
# print(f'Total Average:{avg}')



# f=open('nums.txt','r')
# i=0
# count1=0
# count2=0
# count3=0
# count4=0
# count5=0
# count6=0
# count7=0
# count8=0
# count9=0
# while i <10000:
#     n = int(f.readline())
#     if n==1:
#         count1 += 1
#     elif n==2:
#         count2 += 1
#     elif n==3:
#         count3 += 1
#     elif n==4:
#         count4 += 1
#     elif n==5:
#         count5 += 1
#     elif n==6:
#         count6 += 1
#     elif n==7:
#         count7 += 1
#     elif n==8:
#         count8 += 1
#     elif n==9:
#         count9 += 1
#     i += 1
# print(f'Total Count 1:{count1}')
# print(f'Total Count 2:{count2}')
# print(f'Total Count 3:{count3}')
# print(f'Total Count 4:{count4}')
# print(f'Total Count 5:{count5}')
# print(f'Total Count 6:{count6}')
# print(f'Total Count 7:{count7}')
# print(f'Total Count 8:{count8}')
# print(f'Total Count 9:{count9}')
# f.close()


# f=open('nums.txt','r')
# i=0
# count1=0
# count2=0
# count3=0
# count4=0
# count5=0
# count6=0
# count7=0
# count8=0
# count9=0
# while i <10000:
#     n = int(f.readline())
#     if n==1:
#         count1 += 1
#     elif n==2:
#         count2 += 1
#     elif n==3:
#         count3 += 1
#     elif n==4:
#         count4 += 1
#     elif n==5:
#         count5 += 1
#     elif n==6:
#         count6 += 1
#     elif n==7:
#         count7 += 1
#     elif n==8:
#         count8 += 1
#     elif n==9:
#         count9 += 1
#     i += 1
# print(f'Total Count 1:{count1}')
# print(f'Total Count 2:{count2}')
# print(f'Total Count 3:{count3}')
# print(f'Total Count 4:{count4}')
# print(f'Total Count 5:{count5}')
# print(f'Total Count 6:{count6}')
# print(f'Total Count 7:{count7}')
# print(f'Total Count 8:{count8}')
# print(f'Total Count 9:{count9}')
# f.close()
# f1=open('counts.txt','w')
# f1.write(f'{count1}\n{count2}\n{count3}\n{count4}\n{count5}\n{count6}\n{count7}\n{count8}\n{count9}')
# f1.close()




# f=open('counts.txt','r')
# i=0
# count=0
# while i <9:
#     n = int(f.readline())
#     count += n
#     i += 1
# f.close()
# print(f'Total Count:{count}')




# f = open('letters.txt','r')
# i=0
# ca=0
# cb=0
# while i < 5774:
#     l =  ( f.readline() .strip() )  
#     if l =='a':
#         ca += 1
#     elif l =='b':
#         cb += 1
#     i += 1
# f.close()
# print(f'total number of count A:{ca}')
# print(f'total number of count B:{cb}')


f=open('nums.txt','r')
k=10000
for i in range(1,10):
    count=0
    for j in range(k):
        k=int(f.readline().strip())
        
        if k==(i):
            count+=1
    print(f'count of word {i} is {count}')
f.close()
