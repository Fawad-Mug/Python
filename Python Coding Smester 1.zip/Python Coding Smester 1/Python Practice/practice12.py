x=int(input())
i=0
a=65
c=97
while x>i:
    b=chr(a+i)
    print(b,end='')
    i=i+1
print( )
j=0
while x>j:
    d=chr(c+j)
    print(d,end='')
    j=j+1


x=int(input())
i=0
a=65
c=122
while x>i:
    b=chr(a+i)
    print(b,end=' ')
    d=chr(c-i)
    print(d,end=' ')
    i=i+1


x=int(input())
if x%2==0:
    i=0
    while x>i:
        i=i+1
        print(i,end='')
else:
    i=0
    while x>i:
        print(x,end='')
        x = x-1