x = input('Enter Character')
x = ord(x)
if x & 1:
    print('bit 1 is on')
if x & 2:
    print('bit 2 is on')
if x & 4:
    print('bit 3 is on')
if x & 8:
    print('bit 4 is on')
if x & 16:
    print('bit 5 is on')
if x & 32:
    print('bit 6 is on')
if x & 64:
    print('bit 7 is on')
if x & 128:
    print('bit 8 is on')


from random import *
c1 = randint(65,90)
c2 = randint(65,90) #capital alphabets ahve ascii code 65 to 90
print(f'First character {chr(c1)}\nSecond character is {chr(c2)}')
count = 0
if (c1 & 1) == (c2 & 1):
    count =count+1;
if (c1 & 2) == (c2 & 2):
    count =count+1;
if (c1 & 4) == (c2 & 4):
    count =count+1;
if (c1 & 8) == (c2 & 8):
    count =count+1;
if (c1 & 16) == (c2 & 16):
    count =count+1;
if (c1 & 32) == (c2 & 32):
    count =count+1;
if (c1 & 64) == (c2 & 64):
    count =count+1;
if (c1 & 128) == (c2 & 128):
    count =count+1;
print(f'In {chr(c1)} and {chr(c2)}, {count} bit(s) are same')






from random import *
c1 = randint(65,90)
c2 = randint(65,90) #capital alphabets ahve ascii code 65 to 90
print(f'First character {chr(c1)}\nSecond character is {chr(c2)}')
count = 0
if (c1 & 1) == (c2 & 1):
    count =count+1;
if (c1 & 2) == (c2 & 2):
    count =count+1;
if (c1 & 4) == (c2 & 4):
    count =count+1;
if (c1 & 8) == (c2 & 8):
    count =count+1;
if (c1 & 16) == (c2 & 16):
    count =count+1;
if (c1 & 32) == (c2 & 32):
    count =count+1;
if (c1 & 64) == (c2 & 64):
    count =count+1;
if (c1 & 128) == (c2 & 128):
    count =count+1;

if count == 8:
    print(f'In {chr(c1)} and {chr(c2)} are same')
else :
    print(f'In {chr(c1)} and {chr(c2)} are different ')     




