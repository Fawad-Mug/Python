from random import *
# x1 = randint(1,1000)
# x2 = randint(1,1000)
# x3 = randint(1,1000)
# print (x1, x2, x3)
# if x1 > x2:
#        x1, x2 = x2, x1
# if x2 > x3:
#    x2, x3 = x3, x2
# if x1 > x2:
#    x1, x2 = x2, x1
# print (x1, x2, x3) 
# or we can do this like 
# if x2 > x1 and x2 > x3 :
#    large = x2
# elif x3 > x1 and x3 > x2 :
#    large = x3
# else :
#    large = x1
# if x2 < x1 and x2 < x3: 
#     small = x2
# elif x3 < x1 and x3 < x2:
#     small = x3
# else :
#     small = x1
# if x1 < x2 and x2 > x3:
#     medium = x2
# elif x1 > x2 and x2 < x3:
#     medium = x2
# elif x1 < x3 and x3 > x2:
#     medium = x3
# elif x1 < x3 and x3 < x2:
#     medium = x3
# else : 
#     medium = x1
# print= (f'{small} , {medium} , {large}')


#x1 = randint(1,1000)
#x2 = randint(1,1000)
#x3 = randint(1,1000)
#x4 = randint(1,1000)
#print (x1, x2, x3, x4)
#if x1 > x2:
#    x1, x2 = x2, x1
#if x2 > x3:
#    x2, x3 = x3, x2
#if x3 > x4:
#    x3, x4 = x4, x3
#if x1 > x2:
#   x1, x2 = x2, x1
#if x2 > x3:
#    x2, x3 = x3, x2
#if x1 > x2:
#    x1, x2 = x2, x1
#print (x1, x2, x3, x4) 


#x1 = randint(1,1000)
#x2 = randint(1,1000)
#x3 = randint(1,1000)
#print (x1, x2, x3)
#if x2>x1 and x2<x3  :
#    print('It is same in order')
#else:
#    print('it is not in sme order')
#print (x1, x2, x3)
 
 
# def check_marks(mark1, mark2):
#     if mark1 == mark2:
#         return "SAME"
#     elif (mark1//100) == (mark2//100):
#         return "ALMOST SAME"
#     else:
#         return "DIFFERENT"

# mark1 = int(input("Enter first mark: "))
# mark2 = int(input("Enter second mark: "))

# print(check_marks(mark1, mark2))


x = int(input('Eneter Input'))
if x%2 == 0:
    print('number os divisable by 2')
if x%3 == 0:
    print('number os divisable by 3')
if x%5 == 0:
    print('number os divisable by 5')
if x%7 == 0:
    print('number os divisable by 7')