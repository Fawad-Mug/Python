# i = 0
# while i<100:
#     print(i,end=' ')
#     i =i+2

# x = int(input('Enter Starting Number'))
# y = int(input('Enter Ending Number'))
# while x <= y:
#     print(x,end=' ')
#     x=x+1



# a = int(input('Enter  Number'))
# b = int(input('Enter  Number'))
# c = int(input('Enter  Number'))
# d = int(input('Enter  Number'))
# e = int(input('Enter  Number'))
# sum = a+b+c+d+e
# print(sum)


# a = int(input('Enter  Number'))
# b = int(input('Enter  Number'))
# c = int(input('Enter  Number'))
# d = int(input('Enter  Number'))
# e = int(input('Enter  Number'))
# large = a
# if b>a and b>c and b>d and b>e:
#     large = b
# elif c>a and c>b and c>d and c>e:
#     large = c
# elif d>a and d>b and d>c and d>e:
#     large = d
# elif e>a and e>b and e>c and e>d:
#     large = e
# print(f'Max Number: {large}')


i=1
while i<=49:
    print(i,end=' ')
    i=i+2
