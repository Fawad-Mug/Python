from random import *
# i=1
# while i<=100:
#     if i%3==0:
#         print(f'Number Divisable to :{i}')
#     i=i+1


# i=0
# while i<=100:
#     if i%3==0:
#         print(f'Number Divisable to 3 is:{i}')
#     elif i%5==0:
#         print(f'Number Divisable to 5 is:{i}')
#     i=i+1


i=0
while i<=100:
    if i%3==0:
        print(f'Number Divisable to 3 is:{i}')
    elif i%5==0:
        print(f'Number Divisable to 5 is:{i}')
    if i % 3*5:
        print( )
    i=i+1




# c1 =0
# c2 =0
# n1=randint(1,10)
# n2=randint(1,10)
# if n1>n2:
#     while n1>n2:
#         print(n1)
#         c1 += n1
#         n1 -= 1
# elif n2<n1:
#     while n2<n1:
#         print(n2)
#         c2 += n2
#         n2 -= 1
# print(f'total sum = {c2} {c1}')



# i=0
# count=0
# while i<100:
#     i=i+1
#     print(i,end=' ')
#     count =count+1
#     if count==5:
#         print( )
#         count=0

# i=0
# j=64
# while i<26:
#     i=i+1
#     ch = (chr(i+j))
#     if ch=='A' or ch=='E' or ch=='I' or ch=='O' or ch=='U':
#         print(f'\n{ch}')
#     else:
#         print(ch,end='')