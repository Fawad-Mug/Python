from random import *

# length=5
# x=[0]*length
# for i in range(5):
#     x[i]=randint(20,50)
#     print(x)
# for j in range(5):
#     if x[j]<= x[j+1]:
#         print(x[j],x[j+1])


# length=5
# x=[0]*length
# y=[0]*length
# print(f'List:1 ',end=' ')
# for i in range(5):
#     x[i]=randint(20,50)
#     print(x[i],end= ' ')
# print()
# print(f'List:2 ',end=' ')
# for j in range(5):
#     y[j]=randint(20,50)
#     print(y[j],end= ' ')
# print()
# for i in range(length):
#     if x[i]>y[i]:
#         print(x[i],end=' ')
#     elif y[i]>x[i]:
#         print(y[i],end=' ')



# length=5
# x=[0]*length
# y=[0]*length
# small=[];large=[]
# for i in range(5):
#     x[i]=randint(20,50)
#     y[i]=randint(20,50)
# print(x)
# print(y)
# for i in range(length):
#     if x[i]>y[i]:
#         large.append(x[i])
#         small.append(y[i])
#     elif x[i]<y[i]:
#         large.append(y[i])
#         small.append(x[i])
# print(large)
# print(small)


length=5
x=[0]*length
print(f'List:1 ',end=' ')
for i in range(length):
    x[i]=randint(20,50)
    print(x[i],end= ' ')
print()
def list_sort(length,a):
    for i in range(length):
        if a[i]<a[i+1]:
            return False
        return True
if list_sort(x,length):
    print("List is sorted")
else:
    print("List not sorted")