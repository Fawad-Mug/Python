
n=int(input('Eneter Rows'))
i=1
while i<=n:
    j=1
    while j<=i:
        print(j,end='')
        j+=1
        k=1
        while k<=i:
            print(end=' ')
            k+=1
    print()
    i+=1

n=int(input('Enter Rows'))
for i in range (1,n+1):
    for j in range(1,i+1):
        print(j,end='')
        for k in range (i):
            print(end=' ')
    print()





n=int(input('Enter rows'))
rev=n-1
i=1
while i<=n:
    j=1
    while j<=i:
        print('+',end='')
        j+=1
    print()
    i+=1
i=1
while i<=n:
    i+=1
    j=i
    while j<=n:
        print('+',end='')
        j+=1
    print()


n=int(input('Enter Number'))
for i in range (1,n+1):
    for j in range(1,i+1):
        print('+',end='')
    print()
for i in range (1,n):
    for j in range (0,n-i):
        print('+',end='')
    print()




n=int(input('Enter Number'))
for i in range(1,n+1):
    for j in range(1,i+1):
        print(end=' ')
    for k in range(0,(n+1)-i):
        print('+',end='')
    print()
for i in range(1,n):
    for j in range(i,n):
        print(end=' ')
    for k in range (1,i+2):
        print('+',end='')
    print()





n=int(input('Enter Number'))
for i in range (1,n+1):
    for j in range(0,(n+1)-i):
        print('+',end='')
    for k in range(1,((i+1)*2)-3):
        print(end=' ')
    for l in range(0,(n+1)-i):
        print('+',end='')    
    print()
for i in range (1,n):
    for j in range (1,(i+2)):
        print('+',end='')
    for k in range(1,(n+1)):
        print(end='s')
    for l in range (1,(i+2)):
        print('+',end='')
    print()



n=int(input('Enter Number'))
for i in range (1,n+1):
    for j in range (1,(n+1)*i,i):
        print(chr(j+96),end=' ')
    print()

n=int(input('Enter Rows'))
i=1
while i <=n:
    j=1
    while j<=(n+1)*i:
        print(chr(96+j),end=' ')
        j+=i
    print()
    i+=1



r=int(input('Enter Rows'))
c=int(input('Enter Columns'))
for i in range(1,r+1):
    for j in range(c):
        print(i+j,end=' ')
    print()



r=int(input('Enter Rows'))
c=int(input('Enter Columns'))
for i in range(1,r+1):
    for j in range(c):
        print(end=' ')
    print(i)




r=int(input('Enter Rows'))
for i in range(1,r+1):
    for j in range(1,i):
        print(end=' ')
    print(i)



r=int(input('Enter Rows'))
for i in range(1,r+1):
    for j in range (i,r):
        print(end=' ')
    print(i)



r=int(input('Enter Rows'))
c=int(input('Enter Columns'))
for i in range(1,r+1):
    for j in range(c):
        print(i,end=' ')
    print()

    
r=int(input('Enter Rows'))
c=int(input('Enter Columns'))
for i in range(1,r+1):
    for j in range(c):
        print(i+j,end='')
    print()
    for k in range(c):
        print(chr(96+i+k),end='')
    print()
5
