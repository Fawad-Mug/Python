
from random import *

'''
a=[0]*10
sum=avg=count=count_neg=count_pos=0
for i in range(10):
    a[i]=randint(10,99)
    sum+=a[i]
    count+=1
    print(a[i],end=' ')
avg=sum/count
print(f'\nAverage: {avg}')
for i in range(10):
    sub=avg-a[i]
    if sub>0:
        count_pos+=1
    else:
        count_neg+=1
    print(f'{sub:.2f}',end=' ')
print(f'\nCount Of POstive Number:{count_pos} \nCount Of Negative Number:{count_neg}')


count=sum=avg=0
b=[0]*30
for i in range(30):
    b[i]=randint(1,100)
    print(b[i],end=' ')
    if b[i]>=50:
        count+=1
        sum+=b[i]
    avg=sum/count
print(f'\nAverage:{avg:.4f}')
print ('Marks of Fail students:')
for i in range(30):
    if b[i]<50:
        print(f'{b[i]} ',end=' ')
print ('\nMarks of Above average students:')
for i in range(30):
    if avg>b[i]:
        print(f'{b[i]} ',end=' ')

print ('\nMarks of below average students:')
for i in range(30):
    if avg<b[i]:
        print(f'{b[i]} ',end=' ')


sum=0
for i in range(12):
    c[i]=randint(1000,2000)
    print(c[i],end=' ')
print('\nSales in Two Halves')
for i in range(6):
    sum+=c[i]
print(f'Sales In First Halve:{sum}')
for i in range(6,12):
    sum+=c[i]
print(f'Sales In Second Halve:{sum}')
sum=0
for i in range(3):
    sum += c[i]
print(f'Sale in Quarter 1: {sum}')
sum=0
for i in range(3,6):
    sum += c[i]
print(f'Sale in Quarter 2: {sum}')
sum=0
for i in range(6,9):
    sum += c[i]
print(f'Sale in Quarter 3: {sum}')
sum=0
for i in range(9,12):
    sum += c[i]
print(f'Sale in Quarter 4: {sum}')
'''