# card=input('D for diamond, H for heart, S for Spade and C for Club:')
# if card=='D':
#     card = 'Diamond'
# elif card=='S':
#     card = 'Spade'
# elif card=='H':
#     card = 'Heart'
# elif card=='C':
#     card = 'Club'
# if card == 'Diamond' or card== 'Heart':
#     color = 'Red'
# elif card == 'Spade' or card== 'Club':
#     color = 'Black'
# print (f'The color of card is {color}')


# card=input('D for diamond, H for heart, S for Spade and C for Club:')
# if card=='D':
#     card = 'Diamond'
# elif card=='S':
#     card = 'Spade'
# elif card=='H':
#     card = 'Heart'
# elif card=='C':
#     card = 'Club'
# if card == 'Diamond' or card== 'Heart':
#     color = 'Red'
# elif card == 'Spade' or card== 'Club':
#     color = 'Black'
# print (f'The color of card is {color}')
# from random import *
# select = randint(1,13)
# if select == 1 and card =='Diamond' :
#     print ('Ace of Diamond')
# elif select == 1 and card =='Heart' :
#     print ('Ace of Heart')
# elif select == 1 and card =='Spade' :
#     print ('Ace of Spade')
# elif select == 1 and card =='Club' :
#     print ('Ace of Club')
# elif select == 2 and card =='Diamond' :
#     print ('Two of Diamond')
# elif select == 2 and card =='Heart' :
#     print ('Two of Heart')
# elif select == 2 and card =='Spade' :
#     print ('Two of Spade')
# elif select == 2 and card =='Club' :
#     print ('Two of Club')
# elif select == 3 and card =='Diamond' :
#     print ('Three of Diamond')
# elif select == 3 and card =='Heart' :
#     print ('Three of Heart')
# elif select == 3 and card =='Spade' :
#     print ('Three of Spade')
# elif select == 3 and card =='Club' :
#     print ('Three of Club')
# elif select == 4 and card =='Diamond' :
#     print ('Four of Diamond')
# elif select == 4 and card =='Heart' :
#     print ('Four of Heart')
# elif select == 4 and card =='Spade' :
#     print ('Four of Spade')
# elif select == 4 and card =='Club' :
#     print ('Four of Club')
# elif select == 5 and card =='Diamond' :
#     print ('Five of Diamond')
# elif select == 5 and card =='Heart' :
#     print ('Five of Heart')
# elif select == 5 and card =='Spade' :
#     print ('Five of Spade')
# elif select == 5 and card =='Club' :
#     print ('Five of Club')
# elif select == 6 and card =='Diamond' :
#     print ('Six of Diamond')
# elif select == 6 and card =='Heart' :
#     print ('Six of Heart')
# elif select == 6 and card =='Spade' :
#     print ('Six of Spade')
# elif select == 6 and card =='Club' :
#     print ('Six of Club')
# elif select == 7 and card =='Diamond' :
#     print ('Seven of Diamond')
# elif select == 7 and card =='Heart' :
#     print ('Seven of Heart')
# elif select == 7 and card =='Spade' :
#     print ('Seven of Spade')
# elif select == 7 and card =='Club' :
#     print ('Seven of Club')
# elif select == 8 and card =='Diamond' :
#     print ('Eight of Diamond')
# elif select == 8 and card =='Heart' :
#     print ('Eight of Heart')
# elif select == 8 and card =='Spade' :
#     print ('Eight of Spade')
# elif select == 8 and card =='Club' :
#     print ('Eight of Club')
# elif select == 9 and card =='Diamond' :
#     print ('Nine of Diamond')
# elif select == 9 and card =='Heart' :
#     print ('Nine of Heart')
# elif select == 9 and card =='Spade' :
#     print ('Nine of Spade')
# elif select == 9 and card =='Club' :
#     print ('Nine of Club')
# elif select == 10 and card =='Diamond' :
#     print ('Ten of Diamond')
# elif select == 10 and card =='Heart' :
#     print ('Ten of Heart')
# elif select == 10 and card =='Spade' :
#     print ('Ten of Spade')
# elif select == 10 and card =='Club' :
#     print ('Ten of Club')
# elif select == 11 and card =='Diamond' :
#     print ('Jack of Diamond')
# elif select == 11 and card =='Heart' :
#     print ('Jack of Heart')
# elif select == 11 and card =='Spade' :
#     print ('Jack of Spade')
# elif select == 11 and card =='Club' :
#     print ('Jack of Club')
# elif select == 12 and card =='Diamond' :
#     print ('Queen of Diamond')
# elif select == 12 and card =='Heart' :
#     print ('Queen of Heart')
# elif select == 12 and card =='Spade' :
#     print ('Queen of Spade')
# elif select == 12 and card =='Club' :
#     print ('Queen of Club')
# elif select == 13 and card =='Diamond' :
#     print ('King of Diamond')
# elif select == 13 and card =='Heart' :
#     print ('King of Heart')
# elif select == 13 and card =='Spade' :
#     print ('King of Spade')
# elif select == 13 and card =='Club' :
#     print ('King of Club')





# num = int(input('Enter Three Digit'))
# num_one = num//100
# num_two = (num%100)//10
# num_three = num%10
# print(f'First Number : {num_one}\nSecond Number : {num_two}\nThird Number : {num_three}') 




# num = int(input('Enter Three Digit'))
# num_one = num//100
# num_two = (num%100)//10
# num_three = num%10
# sum = num_one+num_two+num_three
# print(f'Sum of Digits is : {sum}') 




# num = int(input('Enter Three Digit'))
# num_one = num//100
# num_two = (num%100)//10
# num_three = num%10
# print(f'Reverse Number is : {num_three}{num_two}{num_one}') 