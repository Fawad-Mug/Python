# sum=clas=great_avg=0
# less_avg=99999
# f=open('marks.txt','r')
# n=int(f.readline())
# for i in range(n):
#     m=int(f.readline())
#     for j in range(m):
#         marks=int(f.readline())
#         sum+=marks
#     avg=sum//m
#     print(avg)
#     if great_avg<avg:
#         great_avg=avg
#         clas=i+1
#     if less_avg>avg:
#         less_avg=avg
#         inedx=i+1    
# print(great_avg,clas)
# print(less_avg,inedx)



f=open('marks.txt','r')
w=open('marks1.txt','w')
n=int(f.readline())
w.write(f'{n}\n')
for i in range (n):
    mark=int(f.readline())
    w.write(f'{ mark }\n')
    for k in range(mark):
        marks=int(f.readline())
        w.write(f'{ marks } ') 
    w.write('\n')
f.close()
w.close()



# from random import *
# f=open('markssim.txt','w')
# a=5
# for i in range(1,a+1):
#     f.write(f'{a}\n')
#     b=randint(7,10)
#     for j in range(1,b+1):
#         f.write(f'{b}\n')
#         f.write(f'{j}\n')
#         for k in range (1,6):
#             c=randint(50,100)
#             f.write(f'{c} ')

# f.close()

# from random import *
# f=open('matrix.txt','w')
# r=randint(4,8)
# c=randint(4,8)
# f.write(f'{r}\n')
# f.write(f'{c}\n')
# for i in range(r):
#     for j in range(c):
#         x=randint(1,9)
#         f.write(f'{x} ')
#     f.write('\n')

# f.close()