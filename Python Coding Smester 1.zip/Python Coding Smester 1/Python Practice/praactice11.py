from random import *

# i=1
# while i<=10:
#     x= randint(1,10)
#     y = randint(1,10)
#     if x>y:
#         print('First Number is larger')
#     elif y>x: 
#         print('Second Number is larger')
#     i=i+1
    
# i=1
# while i<=10:
#     x = randint(1,10)
#     y = randint(1,10)
#     z = randint(1,10)
#     print(f'random number {x},{y},{z}')
#     if x>y:
#         x,y=y,x
#     if y>z:
#         y,z=z,y
#     if x>y:
#         x,y=y,x
#     print(x,y,z) # we can do this like
#     small = z
#     large = z
#     medium = z
#     if x>y and x>z:
#         large = x
#     elif y>x and y>z: 
#         large = y
#     if x<y and x<z:
#         small = x
#     elif y<x and y<z:
#         small = y
#     if x>y and x<z:
#         medium = x
#     elif x<y and x>z:
#         medium = x
#     elif y>x and y<z:
#         medium = x
#     elif y<x and y>z:
#         medium = x
#     print(f'{small},{medium},{large}')
    # i=i+1
    


# i=1
# while i<=10:
#     x = randint(1,100)
#     print(x)
#     div = x//10
#     rem = x%10
#     if div ==2: print('Tewenty',end=' ')
#     elif div ==3: print('Thirty',end=' ')
#     elif div ==4: print('Fourty',end=' ')
#     elif div ==5: print('Fifty',end=' ')
#     elif div ==6: print('Sixty',end=' ')
#     elif div ==7: print('Seventy',end=' ')
#     elif div ==8: print('Eighty',end=' ')
#     elif div ==9: print('Ninty',end=' ')
#     if x== 10: print('Ten',end=' ')
#     elif x== 11: print('Eleven')
#     elif x== 12: print('Tewelve')
#     elif x== 13: print('Thirteen')
#     elif x== 14: print('Fourteen')
#     elif x== 15: print('Fifteen')
#     elif x== 16: print('Sixteen')
#     elif x== 17: print('Seventeen')
#     elif x== 18: print('Eighteen')
#     elif x== 19: print('Ninteen')
#     elif rem == 1: print('One')
#     elif rem == 2: print('Two')
#     elif rem == 3: print('Three')
#     elif rem == 4: print('Four')
#     elif rem == 5: print('Five')
#     elif rem == 6: print('Six')
#     elif rem == 7: print('Seven')
#     elif rem == 8: print('Eight')
#     elif rem == 9: print('Nine')
#     i=i+1



# i=1
# while i<=10:
#     x= chr(randint(65,97))
#     print('Alphabets x:', end ='')
#     if x == 'A' or x=='E'  or x == 'I' or x== 'O' or x== 'U':
#         print('vOWEL')
#     else:
#         print('constant')
#     i=i+1


# even=0
# odd=0
# x= randint(1,10)
# i=1
# while i<=10:
#     x= randint(1,10)
#     print(f'integers:{x}')
#     if x%2==0:
#         even=even+x
#         print(even)
#     else:
#         odd=odd+x
#         print(odd)
#     i=i+1
# print(even)
# print(odd)