# x =int(input('Enter X2'))
# z =int(input('Enter X1'))
# y = int(input('Enter Y2'))
# a = int(input('Enter Y1'))
# t= int(((x-z)**2 ) + ((y-a)**2))
# c =int(t**0.5)
# print(c)
from math import *
# x = int(input('Enter Radius'))
# x = x**3
# pi= pi.maths
# y = int(1.33*pi*x)
# print(y)

# Initial_Velocity = 45 
# acceleration = 9.8
# time = 2 
# final