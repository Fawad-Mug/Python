from random import *

# f=open('matrix_set1.txt','w')
# w=open('matrix_set2.txt','w')
# a=10
# f.write(f'{(a)}\n')
# w.write(f'{(a)}\n')
# for i in range(1,a+1):
#     r=randint(2,6)
#     c=randint(2,6)
#     f.write(f'{r}\n')
#     w.write(f'{r}\n')
#     f.write(f'{c}\n')
#     w.write(f'{c}\n')
#     for k in range(r):
#         value=randint(0,9)
#         for j in range(c):
#             f.write(f'{value}\n')
#             w.write(f'{value}\n')
# f.close()
# w.close()

# sum=0
# diff=0
# fr=open('matrix_set1.txt','r')
# fw=open('sum.txt','w')
# ww=open('difftxt','w')
# n=int(fr.readline())
# fw.write(f'{n}\n')
# ww.write(f'{n}\n')
# for i in range(1,n+1):
#     r=int(fr.readline())
#     c=int(fr.readline())
#     fw.write(f'{r}\n')
#     ww.write(f'{r}\n')
#     fw.write(f'{c}\n')
#     ww.write(f'{c}\n')
#     for j in range(1,r+1):
#         for k in range(1,c+1):
#             read=int(fr.readline())
#             sum+=read
#             diff-=read
#     fw.write(str(sum))
#     ww.write(str(diff))
# fr.close()
# fw.close()
# ww.close()        




# f=open ('marks.txt','r')
# no_exam=0
# count=int(f.readline())
# for i in range(count):
#     rollno=int(f.readline())
#     m1=int(f.readline())
#     if m1==-2:
#         no_exam+=1
#         continue
#     m2=int(f.readline())
#     m3=int(f.readline())
#     m4=int(f.readline())
# print(f'numbers of absent student in exam {no_exam}')
# print(f'numbers of  student who gave in exam {no_exam - count}')
# f.close()






# f=open ('marks.txt','r')
# no_exam=0
# count=int(f.readline())
# for i in range(count):
#     sum=count=0
#     rollno=int(f.readline())
#     inputrollno=(int(input()))
#     m1=int(f.readline())
#     if m1==-2 and rollno==inputrollno:
#         print(f'Student cannot Appear in exam ')
#         break
#     elif m1==-1:
#         continue
#     if m1!=-1: count+=1; sum+=m1 ;print(f'Marks Student in 1 subject is {m1}')
#     else: print(f'Student doesnot appear in exam 1')
#     m2=int(f.readline())
#     if m2!=-1: count+=1; sum+=m2 ;print(f'Marks Student in 2 subject is {m2}')
#     else: print(f'Student doesnot appear in exam 2')
#     m3=int(f.readline())
#     if m3!=-1: count+=1 ;sum+=m3; print(f'Marks Student in 3 subject is {m3}')
#     else:print(f'Student doesnot appear in exam 3')
#     m4=int(f.readline()) 
#     if m4!=-1: count+=1 ;sum+=m4 ;print(f'Mark Student in 4 subject is {m4}')
#     else: print(f'Student doesnot appear in exam 4')
#     avg=sum/count
#     print(f'Average:{avg}')
#     break
# f.close()





# f=open ('marks.txt','r')
# all_present_student_in_subjects=0
# count=int(f.readline())
# for i in range(count):
#     count=0
#     rollno=int(f.readline())
#     m1=int(f.readline())
#     if m1==-2: continue
#     elif m1!=-1: count+=1
#     m2=int(f.readline())
#     if m2!=-1: count+=1
#     m3=int(f.readline())
#     if m3!=-1: count+=1
#     m4=int(f.readline())
#     if m4!=-1: count+=1
#     if count==4: all_present_student_in_subjects+=1
# print(all_present_student_in_subjects)
# f.close()




# f=open ('marks.txt','r')
# f1=open('marks_appear.txt','w')
# all_present_student_in_subjects=0
# count=int(f.readline())
# for i in range(count):
#     count=0
#     rollno=int(f.readline())
#     m1=int(f.readline())
#     if m1==-2: continue
#     elif m1!=-1: count+=1
#     m2=int(f.readline())
#     if m2!=-1: count+=1
#     m3=int(f.readline())
#     if m3!=-1: count+=1
#     m4=int(f.readline())
#     if m4!=-1: count+=1
#     if count==4: all_present_student_in_subjects+=1; f1.write(f'{all_present_student_in_subjects}\n{rollno}\n{m1}\n{m2}\n{m3}\n{m4}')

# f.close()
