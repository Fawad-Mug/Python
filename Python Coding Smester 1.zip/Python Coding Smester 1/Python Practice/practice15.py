from random import *
# i=0
# while i<10:
#     x=(randint(0,255))
#     y=(randint(0,255))
#     count=0
#     print(x,y)
#     if (x&1) == (y&1):
#         count=count+1
#     if (x&2) == (y&2):
#         count=count+1
#     if (x&4) == (y&4):
#         count=count+1
#     if (x&8) == (y&8):
#         count=count+1
#     if (x&16) == (y&16):
#         count=count+1
#     if (x&32) == (y&32):
#         count=count+1
#     if (x&64) == (y&64):
#         count=count+1
#     if (x&128) == (y&128):
#         count=count+1
#     print(f'{count}')
#     i=i+1

# x=int(input())
# while x!=0:
#     print(x%8,end='')
#     x=x//8


# k=1
# i=1
# count=0
# while i<=10:
#     x=randint(0,100)
#     y=randint(0,100)
#     z=randint(0,100)
#     print(f'x{x} , y{y} , z{z}')
#     count = (z +y+x)/3
#     if i==1:
#         b_avg = count
#     elif b_avg<count:
#         b_avg = count
#         k=i
#     i=i+1
# print(f'set {k} largest avergae:{b_avg}')



# j=1
# k=1
# i=1
# count=0
# while i<=10:
#     x=randint(0,9)
#     y=randint(0,9)
#     z=randint(0,9)
#     print(f'{x} {y} {z}')
#     count = (z +y+x)/3
#     if i==1:
#        min_avg = b_avg = count
#        min_x=x; min_y=y ; min_z=z
#        max_x =x; max_y=y; max_z=z
#     elif b_avg<count:
#         b_avg = count
#         k=i
#         max_x =x; max_y=y; max_z=z
#     elif min_avg<count:
#         min_avg = count
#         j=i
#         min_x =x; min_y=y; min_z=z
#     i=i+1
# print(f'set {k} largest avergae:{b_avg} and elements is {max_x},{max_y},{max_z}')
# print(f'set {j} Smallest avergae:{min_avg} and elements is {min_x},{min_y},{min_z}')


