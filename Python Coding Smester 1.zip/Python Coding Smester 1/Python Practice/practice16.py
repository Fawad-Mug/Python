from random import *
# i=0
# small=1000000000000000000
# small1=1000000000000000000
# small2=10000000000000000000
# small3=100000000000000000000
# while i<10:
#     x=int(input('Number'))
#     if x <small:
#         small=x
#     elif x<small1:
#         small1=x
#     elif x<small2:
#         small2=x
#     elif x<small3:
#         small3=x
#     i=i+1
# print(small)
# print(small1)
# print(small2)
# print(small3)


# a=randint(0,1)
# b=randint(0,1)
# c=randint(0,1)
# d=randint(0,1)
# e=randint(0,1)
# print(f'{a} {b} {c} {d} {e}')
# c0=c1=0
# if a==0: c0 += 1
# else: c1 += 1
# if b==0: c0 += 1
# else: c1 += 1
# if c==0: c0 += 1
# else: c1 += 1
# if d==0: c0 += 1
# else: c1 += 1
# if e==0: c0 += 1
# else: c1 += 1
# print(f'total numbers of 0:{c0}')
# print(f'total numbers of 0:{c1}')


# a=randint(0,2)
# b=randint(0,2)
# c=randint(0,2)
# d=randint(0,2)
# e=randint(0,2)
# print(f'{a} {b} {c} {d} {e}')
# if a==b: print('Ist and 2nd same')
# if a==c: print('Ist and 3rd same')
# if a==d: print('Ist and 4th same')
# if a==e: print('Ist and 5th same')
# if b==c: print('2nd and 3rd same')
# if b==d: print('2nd and 4th same')
# if b==e: print('2nd and 5th same')
# if c==d: print('3rd and 4th same')
# if c==e: print('3rd and 5th same')
# if d==e: print('4th and 5th same')


# a=int(input())
# b=int(input())
# c=int(input())
# d=int(input())
# e=int(input())
# print(f'{a} {b} {c} {d} {e}')
# print(f'{a-b} {a-c} {a-d} {a-e}')
# print(f'{b-a} {b-c} {b-d} {b-e}')
# print(f'{c-b} {c-a} {c-d} {c-e}')
# print(f'{d-b} {d-c} {d-a} {d-e}')
# print(f'{e-b} {e-c} {e-d} {e-a}')


# x=int(input('enter number'))
# d=2
# while d <= x:
#     if x%d==0:
#         print(f'{x} is divisible {d}')
#     d += 1


# def main():
#     i=1
#     while i<=7:
#         j=1
#         while j<=5:
#             print(f'*' , end=' ')
#             j+=1
#         print()
#         i+=1
# main()



# def main():
#     r=int(input('Enter Rows'))
#     c=int(input('Enter colums'))
#     i=1
#     while i<=r:
#         j=1
#         while j<=c:
#             print(f'*' , end=' ')
#             j+=1
#         print()
#         i+=1
# main()


# def main():
#     r=int(input('Enter Rows'))
#     i=1
#     while i<=r:
#         j=65
#         while j<=90:
#             print(chr(j) , end='')
#             j+=1
#         print()
#         i+=1
# main()



# def main():
#     r=int(input('Enter Rows'))
#     c=int(input('Enter colums'))
#     i=1
#     while i<=r:
#         j=1
#         while j<=c:
#             n=randint(1,9)
#             print(f'{n}' , end=' ')
#             j+=1
#         print()
#         i+=1
# main()


# def main():
#     r=int(input('Enter Rows'))
#     i=1
#     while i<=r:
#         j=0
#         while j<5:
#             print(f'{i+j}' , end=' ')
#             j+=1
#         print()
#         i+=1
# main()