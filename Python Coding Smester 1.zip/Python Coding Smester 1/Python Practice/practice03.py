# eng = int(input('Enter English Masks'))
# urdu = int(input('Enter Urdu Masks'))
# maths = int(input('Enter Maths Masks'))
# islamiyat = int(input('Enter Islamiyat Masks'))
# pak_studies = int(input('Enter Pak Studies Marks'))
# biology = int(input('Enter Biology Masks'))
# chemsitry = int(input('Enter Chemistry Masks'))
# physics = int(input('Enter Physics Masks'))
# eng1 = eng / 75
# urdu1 = urdu /75
# maths1 = maths/75
# islamiyat1 = islamiyat /50
# pak_studies1 = pak_studies/50
# biology1 = biology/75
# chemsitry1 = chemsitry/75
# physics1 = physics /75
# total_obtained = eng + urdu + maths + islamiyat + pak_studies + physics + chemsitry + biology
# total_marks = eng1 + urdu1 + maths1 + islamiyat1 + pak_studies1 + physics1 + chemsitry1 + biology1
# print('Subject\t\tTotal\tObtained')
# print(f'English\t\t75\t{eng}')
# print(f'Urdu\t\t75\t{urdu}')
# print(f'Maths\t\t75\t{maths}')
# print(f'Islamiyat\t\t50\t{islamiyat}')
# print(f'Pak Studies\t\t50\t{pak_studies}')
# print(f'Physics\t\t75\t{physics}')
# print(f'Chemistry\t\t75\t{chemsitry}')
# print(f'Biology\t\t75\t{biology}')
# print(f'TOTAL\t\t525\t{total_obtained}')
# total_obtained = 402
# x = int(input('Enter last Merit Of GC'))
# x= x*1100
# # obtain_percent = (total_obtained/525)
# y = x-total_obtained
# print(f'you need {x} numbers in Tenth ')


# neum = int(input('Enter neumerator'))
# denom = int(input('Enter Denominator'))
# ans = neum/denom
# print(ans)



milk = int(input('Enter Milk Budget'))
sugar = int(input('Enter Sugar Budget'))
tea = int(input('Enter tea Budget'))
biscuits = int(input('Enter biscuits Budget'))
milk = int((milk*0.2)+milk)
sugar = int((sugar*0.2)+sugar)
tea = int((tea*0.2)+tea)
biscuits = int((biscuits*0.2)+biscuits)
total = milk + sugar + tea + biscuits
print(f'Milk:\t\t{milk}')
print(f'Sugar:\t\t{sugar}')
print(f'Tea:\t\t{tea}')
print(f'Biscuits:\t{biscuits}')
print('---------------------------------')
print(f'Total\t\t{total}')