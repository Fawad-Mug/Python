from random import *
def main():
    rows = randint(3,6)
    print(f'Rows: {rows}')
    i = 1
    while i <= rows:
        j = 1
        while j <= i:
            print(end='* ')
            j = j + 1
        print(
            
        )
        i = i + 1
main()

