print('Practice 01')
print('Programming Fundamentals.')
print('First Semester')
print('My Programs')
print()
print('First\t\t\tSecond\tThird.py')

