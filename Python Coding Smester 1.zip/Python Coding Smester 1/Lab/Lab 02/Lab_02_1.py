print('This is the first line of my program.')
print('This is the second line of my program.')
print('Program Ended.')
