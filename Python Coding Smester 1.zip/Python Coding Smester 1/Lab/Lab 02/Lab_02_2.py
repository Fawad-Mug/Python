print('First Name\tLast Name\tDegree\tRoll no\tBatch')
print('Ali\t\tMunir\t\tDS\t\t001\t\tF22')
print('Ayesha\tRazzaq\tDS\t\t002\t\tF22')
