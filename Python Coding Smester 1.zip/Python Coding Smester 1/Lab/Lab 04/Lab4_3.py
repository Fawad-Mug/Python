from random import *

n = randint(0,20)
print(f'Number {n} in English is ', end='')
if n==0:        print('zero');
elif n==1:      print('one');
elif n==2:      print('two');
elif n==3:      print('three');
elif n==4:      print('four');
elif n==5:      print('five');
elif n==6:      print('six');
elif n==7:      print('seven');
elif n==8:      print('eight');
elif n==9:      print('nine');
elif n==10:      print('ten');
elif n==11:      print('eleven');
elif n==12:      print('tweleve');
elif n==13:      print('thirteen');
elif n==14:      print('fourteen');
elif n==15:      print('fifteen');
elif n==16:      print('sixteen');
elif n==17:      print('seventeen');
elif n==18:      print('eighteen');
elif n==19:      print('nineteen');
else:            print('twenty');