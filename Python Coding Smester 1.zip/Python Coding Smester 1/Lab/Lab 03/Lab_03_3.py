height = int (input ('Height = '))
print ('Height after one year = ', height * 2)
print ('Height after second year = ', height * 4)
print ('Height after third year = ', height * 8)
print ('Height after fourth year = ', height * 16)
print ('Height after fifth year = ', height * 32)

