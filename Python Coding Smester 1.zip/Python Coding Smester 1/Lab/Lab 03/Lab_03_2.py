amount = int (input ('Amount Deposited = '))
print ('Amount after one year = ', int(amount * 1.1))
print ('Amount after second year = ', int(amount * 1.1 * 1.1))
print ('Amount after third year = ', int(amount * 1.1 * 1.1 * 1.1))
